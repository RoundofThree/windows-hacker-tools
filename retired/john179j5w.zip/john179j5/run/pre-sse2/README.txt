Only use program executables found in this directory if you're getting
the "Sorry, SSE2 is required" message when trying to run one of the main
John the Ripper executables, meaning that you're on a very old computer
(like Pentium 3 or older).

john.exe will work well for most old computers.  If your old computer
has more than one CPU, try john-omp.exe.

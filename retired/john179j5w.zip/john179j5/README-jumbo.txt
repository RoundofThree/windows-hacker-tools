The jumbo patch, which has been applied to this source tree of John the
Ripper, adds a lot of code, documentation, and data contributed by the
user community.  This is not "official" John the Ripper code.  It is
very easy for new code to be added to the jumbo patch: the quality
requirements are low.  This means that you get a lot of functionality
that is not "mature" enough or is otherwise inappropriate for the
official JtR, which in turn also means that bugs in this code are to be
expected, etc.

If you have any comments on this release or on JtR in general, please
join the john-users mailing list and post in there.

Licensing info:
http://openwall.info/wiki/john/licensing

How to contribute more code:
http://openwall.info/wiki/how-to-make-patches
